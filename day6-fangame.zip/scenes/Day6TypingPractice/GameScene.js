export class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });

        this.character = 1;
        this.nickname = '';
        this.score = 0;
        this.health = 100;

        this.nicknameText = null;
        this.scoreText = null;
        this.healthText = null;

        this.portrait = null;
        this.portrait_key = '';
        this.textInput = null;
        this.textInputText = null;
        this.inputBar = null;

        this.lyricsRawList = [];
        this.lyricsMaskedList = [];

        this.previousSentence = { raw: "", masked: "" };
        this.currentSentence = { raw: "", masked: "" };
        this.upcomingSentence = { raw: "", masked: "" };
        this.previousSentenceText = null;
        this.currentSentenceText = null;
        this.upcomingSentenceText = null;

        this.levelTimer = 0;
        this.typingTimer = 30 * 1000;
        this.typingTimerLimit = 30 * 1000;
        this.portraitTimer = null;
        this.timeBar = null;

        this._onTextInputKeyDown = null;
        this._gameOverHandled = false;
    }

    init(data) {
        this.character = data.character;
        this.nickname = data.nickname;
        this.score = 0;
        this.health = 100;

        this.portrait_key = 'face' + data.character;
        this.previousSentence = { raw: "", masked: "" };
        this.currentSentence = { raw: "", masked: "" };
        this.upcomingSentence = { raw: "", masked: "" };

        this.levelTimer = 0;
        this.typingTimer = 30 * 1000;
        this.typingTimerLimit = 30 * 1000;
        this._gameOverHandled = false;
    }

    preload() {
        this.load.text('lyrics_raw', 'assets/Day6TypingPractice/lyrics_raw.txt');
        this.load.text('lyrics_masked', 'assets/Day6TypingPractice/lyrics_masked.txt');
    }

    create() {
        // 애니메이션
        if (!this.anims.exists('timeBox:doodle')) {
            this.anims.create({ key: "timeBox:doodle", frames: "timeBox", frameRate: 4, repeat: -1 });
        }

        // 배경
        this.add.image(800, 600, 'background').setDisplaySize(1600, 1200).setTint(0xf8ddac).setAlpha(0.4);

        // 테두리
        this.add.image(100, 150, 'timeBar').setDisplaySize(1400, 10).setOrigin(0, 0).setTintFill(0x141361);
        this.add.image(100, 1050, 'timeBar').setDisplaySize(1400, 10).setOrigin(0, 0).setTintFill(0x141361);

        // 얼굴 스프라이트
        this.portrait = this.add.sprite(140, 200, this.portrait_key)
            .setDisplaySize(280, 280)
            .setOrigin(0, 0)
            .setTintFill(0x141361)
            .play(this.portrait_key + ':normal');

        // 가사 불러오기
        this.lyricsRawList = this.cache.text.get('lyrics_raw').split(/\r?\n/).filter(Boolean);
        this.lyricsMaskedList = this.cache.text.get('lyrics_masked').split(/\r?\n/).filter(Boolean);

        // 문장 보여주기
        WebFont.load({
            custom: { families: ['DOSIyagiBoldface'] },
            active: () => {
                this.previousSentenceText = this.add.text(800, 560, "", { fontFamily: "DOSIyagiBoldface", fontSize: '48px', fill: '#ac9292' }).setOrigin(0.5).setPadding({ top: 4, bottom: 4 });
                this.currentSentenceText = this.add.text(800, 670, "", { fontFamily: "DOSIyagiBoldface", fontSize: '72px', fill: '#141361' }).setOrigin(0.5).setPadding({ top: 4, bottom: 4 });
                this.upcomingSentenceText = this.add.text(800, 780, "", { fontFamily: "DOSIyagiBoldface", fontSize: '48px', fill: '#ac9292' }).setOrigin(0.5).setPadding({ top: 4, bottom: 4 });
            }
        });

        // UI 텍스트
        WebFont.load({
            custom: { families: ['DOSIyagiBoldface'] },
            active: () => {
                this.add.text(800, 108, "데식타자연습", { fontFamily: "DOSIyagiBoldface", fontSize: '40px', fill: '#141361' }).setOrigin(0.5, 0.5).setPadding({ top: 4, bottom: 4 });
                this.add.text(100, 108, "← 홈으로", { fontFamily: "DOSIyagiBoldface", fontSize: '40px', fill: '#141361' }).setOrigin(0, 0.5).setPadding({ top: 4, bottom: 4 })
                .setInteractive().on('pointerdown', () => {
                    window.open("https://callthefront3-day6-fangame.pages.dev", "_self");
                });
                this.nicknameText = this.add.text(460, 200, this.nickname, { fontFamily: "DOSIyagiBoldface", fontSize: '60px', fill: '#141361' }).setPadding({ top: 4, bottom: 4 });
                this.healthText = this.add.text(460, 300, '체력: 100', { fontFamily: "DOSIyagiBoldface", fontSize: '60px', fill: '#141361' }).setPadding({ top: 4, bottom: 4 });
                this.scoreText = this.add.text(460, 400, '점수: 0', { fontFamily: "DOSIyagiBoldface", fontSize: '60px', fill: '#141361' }).setPadding({ top: 4, bottom: 4 });
                this.textInputText = this.add.text(160, 868, "", { fontFamily: "DOSIyagiBoldface", fontSize: '48px', fill: '#141361' }).setPadding({ top: 4, bottom: 4 });
            }
        });

        // 타임바
        this.add.sprite(100, 960, 'timeBox').setDisplaySize(1400, 40).setOrigin(0, 0).setTintFill(0x141361).play('timeBox:doodle');
        this.timeBar = this.add.image(100, 980, 'timeBar').setDisplaySize(1380, 40).setOrigin(0, 0.5).setTintFill(0x141361);
        this.timeBar.fullWidth = this.timeBar.width;
        this.timeBar.thisLimit = this.typingTimerLimit;

        // 텍스트 입력 DOM
        this.textInput = document.getElementById('textInput');
        this.textInput.setAttribute('maxlength', '25');

        this.inputBar = this.add.sprite(140, 860, 'inputBar').setDisplaySize(1320, 80).setOrigin(0, 0).setTintFill(0x141361).play('inputBar:doodle')
            .setInteractive()
            .on('pointerdown', () => {
                this.textInput.focus();
            });

        // 커서 깜빡임
        this.time.addEvent({
            delay: 500,
            loop: true,
            callback: () => {
                this.cursorVisible = !this.cursorVisible;
            }
        });

        // 이벤트 핸들러 저장 후 등록
        this._onTextInputKeyDown = (event) => {
            if (event.key === 'Enter' && this.textInput.value !== '') {
                this.checkTypedSentence();
            }
        };
        this.textInput.addEventListener('keydown', this._onTextInputKeyDown);

        // 씬 종료 시 이벤트 해제
        this.events.on('shutdown', this.onShutdown, this);
        this.events.on('destroy', this.onShutdown, this);

        // 초기 문장 세팅
        let randIdx = Phaser.Math.Between(0, this.lyricsRawList.length - 1);
        let raw = this.lyricsRawList[randIdx];
        let masked = this.lyricsMaskedList[randIdx];
        this.currentSentence = { raw: raw, masked: masked };

        randIdx = Phaser.Math.Between(0, this.lyricsRawList.length - 1);
        raw = this.lyricsRawList[randIdx];
        masked = this.lyricsMaskedList[randIdx];
        this.upcomingSentence = { raw: raw, masked: masked };
    }

    update(_, delta) {
        this.typingTimer -= delta;
        this.levelTimer += delta;

        // 안전한 timeLimit 사용
        const timeLimit = (this.timeBar && typeof this.timeBar.thisLimit === 'number')
            ? this.timeBar.thisLimit
            : this.typingTimerLimit;

        const progress = Phaser.Math.Clamp(this.typingTimer / Math.max(1, timeLimit), 0, 1);

        if (this.timeBar && typeof this.timeBar.setCrop === 'function' && typeof this.timeBar.fullWidth === 'number') {
            this.timeBar.setCrop(0, 0, this.timeBar.fullWidth * progress, this.timeBar.height || 40);
        }

        // 레벨 변경
        if (this.levelTimer > 30 * 1000) {
            this.typingTimerLimit -= 3 * 1000;
            this.typingTimerLimit = this.typingTimerLimit <= 10 * 1000 ? 10 * 1000 : this.typingTimerLimit;
            this.levelTimer = 0;
        }

        // 시간 초과
        if (this.typingTimer <= 0) {
            this.timeOver();
        }

        // 체력 0
        if (this.health <= 0) {
            this.gameOver();
        }

        // 문장 텍스트 표시 (씬에 속해있는 오브젝트만)
        const canSetText = obj => obj && typeof obj.setText === 'function' && obj.scene === this;
        if (canSetText(this.previousSentenceText) && canSetText(this.currentSentenceText) && canSetText(this.upcomingSentenceText)) {
            this.previousSentenceText.setText(this.previousSentence.raw);

            if(timeLimit == 30 * 1000) {
                this.currentSentenceText.setText(this.currentSentence.raw);
                this.upcomingSentenceText.setText(this.upcomingSentence.raw);
            } else {
                this.currentSentenceText.setText(this.currentSentence.masked);
                this.upcomingSentenceText.setText(this.upcomingSentence.masked);
            }
        }

        // 입력창 갱신
        if (this.textInputText && this.textInput.value != '') {
            this.textInputText.setColor('#141361');
            if (this.textInput.getAttribute('focused') === 'true') {
                const cursor = this.cursorVisible ? '█' : '';
                this.textInputText.setText(this.textInput.value + cursor);
            } else {
                this.textInputText.setText(this.textInput.value);
            }
        } else if (this.textInputText && this.textInput.value == '') {
            this.textInputText.setColor('#ac9292');
            this.textInputText.setText("가사를 입력해 주세요");
        }
    }

    pickSentence() {
        this.previousSentence = this.currentSentence;
        this.currentSentence = this.upcomingSentence;
        
        const randIdx = Phaser.Math.Between(0, this.lyricsRawList.length - 1);
        const raw = this.lyricsRawList[randIdx];
        const masked = this.lyricsMaskedList[randIdx];
        this.upcomingSentence = { raw: raw, masked: masked };

        this.typingTimer = this.typingTimerLimit;
        if (this.timeBar) this.timeBar.thisLimit = this.typingTimerLimit;
    }

    checkTypedSentence() {
        const typed = this.textInput.value.trim();

        if (this.currentSentence.raw === typed) {
            this.pickSentence();
            this.score += 10;

            this.portrait.play(this.portrait_key + ':joy');
            this.time.delayedCall(3000, () => this.portrait.play(this.portrait_key + ':normal'));

            this.sound.play('good');
        } else {
            this.typingTimer = Math.max(1, this.typingTimer - 3 * 1000);

            if (this.portraitTimer)
                this.portraitTimer.remove(false);

            this.portrait.play(this.portrait_key + ':sad');
            this.portraitTimer = this.time.delayedCall(3000, () => {
                this.portrait.play(this.portrait_key + ':normal');
                this.portraitTimer = null;
            });

            this.sound.play('fail');
            this.cameras.main.shake(200, 0.003);
        }

        this.textInput.value = '';
        this.updateScoreAndHealth();
    }

    updateScoreAndHealth() {
        if (this.scoreText && this.healthText) {
            this.healthText.setText(`체력: ${this.health}`);
            this.scoreText.setText(`점수: ${this.score}`);
        }
    }

    timeOver() {
        this.pickSentence();
        this.health -= 10;

        if (this.portraitTimer)
            this.portraitTimer.remove(false);

        this.portrait.play(this.portrait_key + ':sad');
        this.portraitTimer = this.time.delayedCall(3000, () => {
            this.portrait.play(this.portrait_key + ':normal');
            this.portraitTimer = null;
        });

        this.sound.play('fail');
        this.cameras.main.shake(200, 0.003);

        this.updateScoreAndHealth();
    }

    gameOver() {
        if (this._gameOverHandled) return;
        this._gameOverHandled = true;
        this.scene.start("ScoreBoardScene", { 'nickname': this.nickname, 'character': this.character, 'score': this.score });
        this.textInput.value = '';
        this.textInputText = null;
    }

    playTypingSound() {
        const randomKey = Phaser.Utils.Array.GetRandom(['typing1', 'typing2', 'typing3', 'typing4', 'typing5']);
        this.sound.play(randomKey);
    }

    onShutdown() {
        if (this.textInput && this._onTextInputKeyDown) {
            this.textInput.removeEventListener('keydown', this._onTextInputKeyDown);
            this.textInput.style.display = 'none';
            this.textInput.value = '';
        }
    }
}
